fastly-node-syslog
==================

Node endpoint for fastly's syslog stream
