var Root = require('../../build/public/js/components/Root');

React.renderComponent(new Root({}), document.getElementById('root'));